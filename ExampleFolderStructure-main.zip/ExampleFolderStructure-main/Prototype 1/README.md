# Prototype 1 - Horizontal Unity Prototype

This folder contains your first Unity prototype project files and documentation. 